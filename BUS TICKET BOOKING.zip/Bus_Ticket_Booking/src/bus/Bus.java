package bus;

public abstract class Bus {

    protected String busNumber;
    protected String type; 
    public String seatType; 
    protected double fare;
    protected int totalSeats;
    protected boolean[] seatAvailability;

    public Bus(String busNumber, String type, String seatType) {
        this.busNumber = busNumber;
        this.type = type;
        this.seatType = seatType;
        this.fare = calculateFare();
        this.totalSeats = seatType.equalsIgnoreCase("Seater") ? 40 : 30;
        this.seatAvailability = new boolean[totalSeats];
        
        for (int i = 0; i < totalSeats; i++) {
            seatAvailability[i] = false;
        }
    }
    
    //abstract method-pol-imple
    public abstract double calculateFare(); 
    
    //getter methods-encap
    public double getFare() { 
        return fare; 
    }
    
    public String getBusNumber() {
        return busNumber;
    }

    public String getType() {
        return type;
    }

    public String getSeatType() {
        return seatType;
    }


    
    public void displayDetails() {
        System.out.println("Bus Number: " + busNumber);
        System.out.println("Type: " + type);
        System.out.println("Seat Type: " + seatType);
        System.out.println("Fare: " + fare);
    }
    //seat allocation mechanism
    public int allocateSeat(String sleeperPosition) {
        int start = 0, end = totalSeats;
        if (seatType.equalsIgnoreCase("Sleeper")) {
            if (sleeperPosition.equalsIgnoreCase("Upper")) {
                start = 15; end = 30;
            } else {
                start = 0; end = 15;
            }
        }
  
        for (int i = start; i < end; i++) {
            if (!seatAvailability[i]) {
                seatAvailability[i] = true;
                return i + 1;
            }
        }
        return -1; 
    }
}