package bus;

public class NonACBus extends Bus {
	 public NonACBus(String busNumber, String seatType) {
	        super(busNumber, "Non-AC", seatType);
	    }
	    
	    @Override
	    public double calculateFare() {
	        double baseFare = 500;
	        if (seatType.equalsIgnoreCase("Sleeper")) baseFare += 150;
	        return baseFare;
	    }
	}