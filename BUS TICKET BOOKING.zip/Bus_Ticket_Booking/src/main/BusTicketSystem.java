package main;

import java.util.*;
import booking.Ticket;
import bus.Bus;
import bus.BusDatabase;
import exception.InvalidInputException;
import utility.Logger;
import java.util.ArrayList;

public class BusTicketSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Ticket> tickets = new ArrayList<>();
        boolean running = true;

        while (running) {
            System.out.println("*Bus Ticket Management System*");
            System.out.println("1. Display All the buses");
            System.out.println("2. Add Passenger");
            System.out.println("3. Display Passenger Details");
            System.out.println("4. Remove Passenger");
            System.out.println("5. Make Payment");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {

                case 1:
                    List<Bus> availableBuses = BusDatabase.getAllBuses();
                    if (availableBuses.isEmpty()) {
                        System.out.println("No buses available at the moment.");
                    } else {
                        System.out.println("\n---- Available Buses ----");
                        for (Bus bus : availableBuses) {
                            bus.displayDetails();
                            System.out.println("---------------------------");
                        }
                    }
                    break;

                case 2:
                    try {
                        System.out.print("Enter Bus Number: ");
                        String busNumber = scanner.nextLine();
                        
                        // 🔹 Fetch bus from the BusDatabase
                        Bus bus = BusDatabase.getBusByNumber(busNumber);
                        if (bus == null) {
                            System.out.println("❌ Bus not found! Please enter a valid bus number.");
                            break;
                        }

                        System.out.print("Enter Passenger Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Age: ");
                        int age = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Starting Destination: ");
                        String startDestination = scanner.nextLine();
                        System.out.print("Enter Ending Destination: ");
                        String endDestination = scanner.nextLine();
                        System.out.print("Enter Boarding Date (YYYY-MM-DD): ");
                        String boardingDate = scanner.nextLine();

                        String sleeperPosition = "Not Applicable";
                        if (bus.getSeatType().equalsIgnoreCase("Sleeper")) {
                            System.out.print("Enter Sleeper Position (Upper/Lower): ");
                            sleeperPosition = scanner.nextLine();
                        }

                        // 🔹 Allocate seat
                        int seatNumber = bus.allocateSeat(sleeperPosition);
                        if (seatNumber == -1) {
                            System.out.println("❌ Sorry, no available seats in this section!");
                            break;
                        }

                        // 🔹 Create and add ticket
                        Ticket ticket = new Ticket(bus, name, age, seatNumber, sleeperPosition, startDestination, endDestination, boardingDate);
                        tickets.add(ticket);
                        System.out.println("✅ Passenger added successfully!");

                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 3:
                    if (tickets.isEmpty()) {
                        System.out.println("No passengers booked yet.");
                    } else {
                        System.out.println("\n---- Passenger Details ----");
                        double totalFare = 0;
                        for (Ticket t : tickets) {
                            t.displayTicket(); // Display ticket details
                            totalFare += t.getFare();
                            System.out.println("---------------------------");
                        }
                    }
                    break;

                case 4:
                    System.out.print("Enter Passenger Name to Remove: ");
                    String removeName = scanner.nextLine();
                    tickets.removeIf(t -> t.getPassengerName().equalsIgnoreCase(removeName));
                    System.out.println("Passenger removed.");
                    break;

                case 5: // Make Payment and Show Ticket
                    if (tickets.isEmpty()) {
                        System.out.println("No passengers booked yet.");
                    } else {
                        double totalFare = 0;
                        System.out.println("\n---- Payment Details ----");
                        for (int i = 0; i < tickets.size(); i++) {
                            Ticket t = tickets.get(i);
                            System.out.println("Passenger " + (i + 1) + " (" + t.getPassengerName() + ") Fare: $" + t.getFare());
                            totalFare += t.getFare();
                        }
                        System.out.println("Total Fare: $" + totalFare);

                        // Payment Confirmation and Type Selection
                        System.out.print("Choose Payment Method (1. Credit Card, 2. Debit Card, 3. Paytm, 4. Cash): ");
                        int paymentChoice = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        
                        String paymentMethod = "";
                        switch (paymentChoice) {
                            case 1: paymentMethod = "Credit Card"; break;
                            case 2: paymentMethod = "Debit Card"; break;
                            case 3: paymentMethod = "Paytm"; break;
                            case 4: paymentMethod = "Cash"; break;
                            default: 
                                System.out.println("Invalid payment method selected.");
                                continue;
                        }

                        System.out.print("Confirm payment of $" + totalFare + " via " + paymentMethod + "? (yes/no): ");
                        String confirmPayment = scanner.nextLine();

                        if (confirmPayment.equalsIgnoreCase("yes")) {
                            System.out.println("✅ Payment Successful via " + paymentMethod + "!");
                            System.out.println("\n---- Booking Successful! ----");
                            for (Ticket t : tickets) {
                                t.displayTicket();
                                System.out.println("---------------------------");
                            }
                        } else {
                            System.out.println("❌ Payment canceled. Booking not confirmed.");
                        }
                    }
                    break;

                case 6:
                    running = false;
                    System.out.println("Thank you for Booking with us..!!!");
                    System.out.println("Have a safe and happy trip........");
                    break;

                default:
                    System.out.println("❌ Invalid choice! Please try again.");
            }
        }

        scanner.close();
    }
}
