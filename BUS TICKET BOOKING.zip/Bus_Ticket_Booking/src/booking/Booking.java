package booking;

public interface Booking {
void bookTicket();

}
